/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q.pkg1_b;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author farzeen
 */
class Student{
     String id,name,address,cgpa;
     String str="";
     Scanner obj=new Scanner(System.in);//standard input
     void addStudent(){
         System.out.print("Enter ID :");
        id=obj.nextLine();
        str=str+id;
        System.out.print("Enter Name :");
        name=obj.nextLine();
        str=str+","+name;
        System.out.print("Enter Address :");
        address=obj.nextLine();
        str=str+","+address;
        System.out.print("Enter CGPA :");
        cgpa=obj.nextLine();
        str=str+","+cgpa+"\n";
     }
}
public class Q1_B {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
           Scanner obj=new Scanner(System.in);//standard input
         int choice;
          File file=new File("student.txt");
         Student s=new Student();
       
        do{  
         System.out.println("\n\nPress 1 to Save data!");
         System.out.println("Press 2 Read Data!");
         System.out.println("Press 3 Exit");
         choice=obj.nextInt();
        switch(choice){
            case 1:
         s.addStudent();
        try {
            PrintWriter output = new PrintWriter(file);
            output.println(s.str);
             output.close();
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Q1_B.class.getName()).log(Level.SEVERE, null, ex);
        }
        break;
            case 2:
                String str="";
                FileReader fr=null;
         {
             try {
                 fr=new FileReader(file);
                 BufferedReader br=new BufferedReader(fr);           
          while((str=br.readLine())!=null){
          System.out.print(str+"\n");
          }
             } catch (FileNotFoundException ex) {
                 Logger.getLogger(Q1_B.class.getName()).log(Level.SEVERE, null, ex);
             } catch (IOException ex) {
                 Logger.getLogger(Q1_B.class.getName()).log(Level.SEVERE, null, ex);
             }
         }
                
                break;
            case 3:
                 System.out.println("Good Bye!");
                 break;
            default:
                System.out.println("Please appropiate input!");
                break;
        }        
       }while(choice!=3);
       
    }
     
    
}
