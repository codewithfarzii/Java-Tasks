/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taskonecopycontentfromonefiletoanother;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author farzeen
 */
public class TaskOneCopyContentFromOneFileToAnother {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        File input=new File("inputfile.txt");
        File output=new File("outputfile.txt");
        FileReader fr=null;
        FileWriter fw=null;
        try{
           fr=new FileReader(input);
           fw=new FileWriter(output);
           int ch;
           while((ch=fr.read())!=-1)
           {
            fw.write(ch);
    }       
        } catch (FileNotFoundException ex) {
            Logger.getLogger(TaskOneCopyContentFromOneFileToAnother.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(TaskOneCopyContentFromOneFileToAnother.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally{
            try {
                fr.close();
                 fw.close();
            } catch (IOException ex) {
                Logger.getLogger(TaskOneCopyContentFromOneFileToAnother.class.getName()).log(Level.SEVERE, null, ex);
            }
          
        }
    }
}
