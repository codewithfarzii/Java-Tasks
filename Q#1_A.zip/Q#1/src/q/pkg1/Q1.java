/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q.pkg1;

import java.util.Scanner;

/**
 *
 * @author farzeen
 */
 class Member{
        int Age,Phone_number;
        String Name,City;
        double Salary;
        Scanner obj=new Scanner(System.in);//standard input
    }
   class Employee extends Member{
       String specialization;
    void Display(){
        System.out.println("\nName: "+this.Name);
         System.out.println("Age: "+this.Age);
          System.out.println("City: "+this.City);
           System.out.println("Phone Number: "+this.Phone_number);
            System.out.println("Salary: "+this.Salary);
            System.out.println("Specialization: "+this.specialization);
    }  
    void TakeInput(){
        System.out.print("Enter Specialization: ");
        this.specialization=obj.nextLine();
        System.out.print("Enter Name: ");
        this.Name=obj.nextLine();
         System.out.print("Enter City: ");
          this.City=obj.nextLine();
         System.out.print("Enter Age: ");
         this.Age=obj.nextInt();
           System.out.print("Enter Phone Number: ");
           this.Phone_number=obj.nextInt();
            System.out.print("Enter Salary: ");
            this.Salary=obj.nextDouble();
    }  
    static void searchBySalasry(Employee[] emp,int len){
         Scanner obj=new Scanner(System.in);//standard input
       double minSalary,maxSalary;
        boolean got=true;
        int dis=1;
         System.out.print("Enter Minimum Salary: ");
         minSalary=obj.nextDouble();
         System.out.print("Enter Maximum Salary: ");
         maxSalary=obj.nextDouble();
        System.out.println("\n\t\t\tEmployees found with Given range and age<50 ");
       
        for(int a=0;a<len;a++){
            if(emp[a].Salary<=maxSalary && emp[a].Salary>=minSalary && emp[a].Age<50){
                System.out.println("\n\t\t\tEmployee No "+dis);
                dis++;
                   emp[a].Display();                   
                got=false;
            }
        }
        if(got){
                 System.out.println("No Employee Found within Range and age<50 ");
        }
        
    }
    static void searchBySpecialization(Employee[] emp,int len){
         Scanner obj=new Scanner(System.in);//standard input
        String userInputt;
        boolean got=true;
        int dis=1;
         System.out.print("Enter Specialization: ");
       userInputt=obj.nextLine();
       System.out.println("\n\t\t\tEmployees found with Specialization ");
        for(int a=0;a<len;a++){
            if(userInputt.matches(emp[a].specialization)){
                System.out.println("\n\t\t\tEmployee No "+dis);
                dis++;
                   emp[a].Display();                   
                got=false;
            }
        }
        if(got){
            System.out.println("No Employee Found with that Specialization ");      
        }
        
    }
}
class Manager extends Member{
    String department;
    void Display(){
        System.out.println("\nDeaprtment: "+this.department);
        System.out.println("Name: "+this.Name);
         System.out.println("Age: "+this.Age);
          System.out.println("City: "+this.City);
           System.out.println("Phone Number: "+this.Phone_number);
            System.out.println("Salary: "+this.Salary);
    }  
     void TakeInput(){
         System.out.print("Enter Department: ");
          this.department=obj.nextLine();
        System.out.print("Enter Name: ");
        this.Name=obj.nextLine();
        System.out.print("Enter City: ");
          this.City=obj.nextLine();
         System.out.print("Enter Age: ");
         this.Age=obj.nextInt();
           System.out.print("Enter Phone Number: ");
           this.Phone_number=obj.nextInt();
            System.out.print("Enter Salary: ");
            this.Salary=obj.nextDouble();
    }  
    
}
public class Q1 {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Scanner obj=new Scanner(System.in);//standard input
        int choice,count=0,count2=0;
        
        // TODO code application logic here
       Employee[] emp=new Employee[100];
       Manager[] man=new Manager[100];
       do{
            
         System.out.println("\n\nPress 1 to add Employee: ");
         System.out.println("Press 2 to Display all Employees: ");
         System.out.println("Press 3 to add Manager: ");
         System.out.println("Press 4 to Display all Managers: ");
         System.out.println("Press 5 to Search Employee By Specializatio: ");
         System.out.println("Press 7 to Exit!");
         choice=obj.nextInt();
        switch(choice){
            case 1:
                if(count<100){
                emp[count]=new Employee();
                emp[count].TakeInput();
                count++;      
                }else   
                     System.out.println("There is 100 Employees already");
                break;
             case 2:
                 if(count>0){
                for(int a=0;a<count;a++)
                emp[a].Display();
                 }else
                     System.out.println("Not Found!");
                break;
             case 3:
                if(count2<100){
                man[count2]=new Manager();
                man[count2].TakeInput();
                count2++;      
                }else   
                     System.out.println("There is 100 Managers already");
                break;
             case 4:
                 if(count2>0){
                for(int a=0;a<count2;a++)
                man[a].Display();
                 }else
                     System.out.println("Not Found!");
                break;
             case 5:
                 if(count>0){               
               Employee.searchBySpecialization(emp,count);
                 }else
                     System.out.println("There is no Employee Yet!");
                break;
             case 6:
                 if(count>0){               
               Employee.searchBySalasry(emp,count);
                 }else
                     System.out.println("There is no Employee Yet!");
                break;
            case 7:
                 System.out.println("Good Bye!");
                 break;
            default:
                System.out.println("Please appropiate input!");
                break;
        }        
       }while(choice!=7);
       
    }
    
}
