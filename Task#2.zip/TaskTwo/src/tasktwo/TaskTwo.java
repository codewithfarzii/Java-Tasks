/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tasktwo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author farzeen
 */
public class TaskTwo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here
        Scanner obj=new Scanner(System.in);//standard input
        File input=new File("inputfile.txt");      
        FileReader fr=null;       
        String SearcWord,str="";
        
        System.out.print("Enter word you want to Search from file :");
        SearcWord=obj.nextLine();       
        
        try{
           fr=new FileReader(input);
           BufferedReader br=new BufferedReader(fr);           
           
           do{
           if(str.contains(SearcWord))
          System.out.print(str+"\n");
           
           }while((str=br.readLine())!=null);
        }
        catch (IOException ex) {            
            Logger.getLogger(TaskTwo.class.getName()).log(Level.SEVERE, null, ex);
        }            
        
        
        finally{            
                try {
                    fr.close();
                } catch (IOException ex) {
                    Logger.getLogger(TaskTwo.class.getName()).log(Level.SEVERE, null, ex);
                }
               
            } 
        }
    }
    
