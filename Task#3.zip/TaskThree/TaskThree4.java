/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taskthree;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author farzeen
 */
public class TaskThree {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        File javafile=new File("taskthree.java");
        File words=new File("Words.txt");
        FileWriter fw=null;        
        String str="";
        
        try {            
            fw = new FileWriter(words);
            PrintWriter pw=new PrintWriter(fw);
           Scanner scan=new Scanner(javafile);
           while(scan.hasNextLine()){
             //str=scan.next();
        
             //  pw.println(str);
             
    // System.out.println(scan.next());
        
           }
           
        } 
        catch (IOException ex) {
            Logger.getLogger(TaskThree.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally {
            try {
                fw.close();
            }
            catch (IOException ex) {
                Logger.getLogger(TaskThree.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        
    }
    
}
